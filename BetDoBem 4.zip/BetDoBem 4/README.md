# Bet do Bem

Projeto acadêmico Android Studio: Kotlin + Jetpack Compose + padrão MVVM + SQLiteOpenHelper.

## Importar
Abra a **pasta do projeto** no Android Studio (File > Open) e sincronize com o Gradle e Android SDK 34.

## Funcionalidades
Login, cadastro, sessão, futebol, basquete, bilhetes, usuários, times, campanhas, consulta de CEP por Retrofit/ViaCEP e abertura nativa de mapa.

Consulte **GUIA_DEFESA_E_REQUISITOS.md** para a localização de cada requisito e o roteiro da apresentação.

É um protótipo didático com saldo e cotações simulados, sem apostas com dinheiro real.
