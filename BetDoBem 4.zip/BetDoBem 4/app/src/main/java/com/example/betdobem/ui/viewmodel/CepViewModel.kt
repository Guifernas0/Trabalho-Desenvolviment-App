package com.example.betdobem.ui.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.betdobem.data.model.EnderecoCep
import com.example.betdobem.data.remote.CepService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class CepViewModel : ViewModel() {
    var endereco by mutableStateOf<EnderecoCep?>(null)
        private set
    var mensagem by mutableStateOf<String?>(null)
        private set
    var carregando by mutableStateOf(false)
        private set

    fun consultar(cep: String) {
        val numeros = cep.filter { it.isDigit() }
        if (numeros.length != 8) { mensagem = "Informe um CEP com 8 números."; return }
        carregando = true
        mensagem = null
        endereco = null
        viewModelScope.launch {
            try {
                val resultado = CepService.api.consultar(numeros)
                if (resultado.erro == true) mensagem = "CEP não encontrado."
                else endereco = resultado
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { mensagem = "Não foi possível consultar a API. Verifique sua internet." }
            finally { carregando = false }
        }
    }
}
