package com.example.betdobem.data.dal

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import com.example.betdobem.data.local.AppDatabase
import com.example.betdobem.data.model.Usuario

internal class SenhaSalva(val hash: ByteArray, val salt: ByteArray, val usuarioID: Long)

internal class UsuarioDao(context: Context) {
    private val appContext = context.applicationContext

    private val colunas = arrayOf(
        "id", "nome", "email", "saldo", "cpf", "estado",
        "rua", "bairro", "cep", "ddd", "celular"
    )

    fun cadastrar(nome: String,
                  email: String,
                  senha: ByteArray,
                  salt: ByteArray
    ) {
        AppDatabase(appContext).use { db ->
            val dados = ContentValues().apply {
                put("nome", nome)
                put("email", email)
                put("senha", senha)
                put("salt", salt)
            }
            db.writableDatabase
                .insertOrThrow("usuarios",
                    null,
                    dados)
        }
    }

    fun buscarSenha(email: String): SenhaSalva? {
        return AppDatabase(appContext).use { db ->
            db.readableDatabase.query(
                "usuarios",
                arrayOf("senha", "salt", "id"),
                "email = ?",
                arrayOf(email),
                null, null, null
            ).use { usuario ->
                if (usuario.moveToFirst()) SenhaSalva(
                    usuario.getBlob(0),
                    usuario.getBlob(1), usuario.getLong(2)
                ) else null
            }
        }
    }

    fun listar(): List<Usuario> = AppDatabase(appContext).use { db ->
        db.readableDatabase.query(
            "usuarios",
            colunas,
            null, null, null, null,
            "nome COLLATE NOCASE, id"
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    add(lerUsuario(cursor))
                }
            }
        }
    }

    fun buscarPorId(id: Long): Usuario? = AppDatabase(appContext).use { db ->
        db.readableDatabase.query(
            "usuarios",
            colunas,
            "id = ?",
            arrayOf(id.toString()),
            null, null, null
        ).use { cursor ->
            if (cursor.moveToFirst()) lerUsuario(cursor)
            else null
        }
    }

    fun alterar(usuario: Usuario,
                hash: ByteArray? = null,
                salt: ByteArray? = null) {
        AppDatabase(appContext).use { db ->
            val dados = ContentValues().apply {
                put("nome", usuario.nome)
                put("cpf", usuario.cpf)
                put("estado", usuario.estado)
                put("rua", usuario.rua)
                put("bairro", usuario.bairro)
                put("cep", usuario.cep)
                put("ddd", usuario.ddd)
                put("celular", usuario.celular)
                if (hash != null) put("senha", hash)
                if (salt != null) put("salt", salt)
            }
            val alterados = db.writableDatabase.update(
                "usuarios",
                dados,
                "id = ?",
                arrayOf(usuario.id.toString()))
            require(alterados == 1) { "Erro ao alterar o usuário" }
        }
    }

    fun alterarSaldo(id: Long, saldo: Double) {
        AppDatabase(appContext).use { db ->
            val dados = ContentValues().apply {
                put("saldo", saldo)
            }
            val alterados = db.writableDatabase.update(
                "usuarios",
                dados,
                "id = ?",
                arrayOf(id.toString()))
            require(alterados == 1) { "Erro ao alterar o saldo" }
        }
    }

    fun excluir(id: Long, usuarioAtualid: Long) {
        require(id != usuarioAtualid) { "Você não pode excluir seu próprio usuário" }

        AppDatabase(appContext).use { db ->
            // Apaga também as apostas do usuário
            db.writableDatabase.delete(
                "apostas", "usuario_id = ?",
                arrayOf(id.toString())
            )
            val excluidos = db.writableDatabase.delete(
                "usuarios", "id = ? AND id <> ?",
                arrayOf(id.toString(), usuarioAtualid.toString())
            )
            require(excluidos == 1) { "Usuário não pode ser excluído" }
        }
    }

    private fun lerUsuario(cursor: Cursor): Usuario {
        return Usuario(
            cursor.getLong(0),
            cursor.getString(1),
            cursor.getString(2),
            cursor.getDouble(3),
            cursor.getString(4),
            cursor.getString(5),
            cursor.getString(6),
            cursor.getString(7),
            cursor.getString(8),
            cursor.getString(9),
            cursor.getString(10)
        )
    }
}
