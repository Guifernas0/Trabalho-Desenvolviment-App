package com.example.betdobem.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.toRoute
import com.example.betdobem.auth.SessaoUsuario
import com.example.betdobem.ui.screens.BilhetesScreen
import com.example.betdobem.ui.screens.CadastroScreen
import com.example.betdobem.ui.screens.JogosScreen
import com.example.betdobem.ui.screens.LoginScreen
import com.example.betdobem.ui.screens.UsuarioEditarScreen
import com.example.betdobem.ui.screens.UsuariosScreen
import com.example.betdobem.ui.screens.jogosDeBasquete
import com.example.betdobem.ui.screens.jogosDeFutebol
import com.example.betdobem.ui.viewmodel.UsuarioViewModel
import com.example.betdobem.ui.viewmodel.RegistroViewModel
import com.example.betdobem.ui.viewmodel.CepViewModel
import com.example.betdobem.ui.screens.RegistrosScreen
import com.example.betdobem.ui.screens.ConsultaCepScreen

@Composable
fun AppNavigation(navController: NavHostController, modifier: Modifier) {
    val rotaAtual by navController.currentBackStackEntryAsState()
    val destino = rotaAtual?.destination
    val usuarioAtual = SessaoUsuario.usuarioId

    // Controle de sessão: sem usuário logado, só Login e Cadastro podem abrir
    LaunchedEffect(destino, usuarioAtual) {
        val publica = destino?.hasRoute<Login>() == true ||
                destino?.hasRoute<Cadastro>() == true

        if (destino != null && !publica && usuarioAtual == null) {
            navController.navigate(Login) {
                popUpTo(0) { inclusive = true }
                launchSingleTop = true
            }
        }
    }
    NavHost(
        navController = navController,
        startDestination = Login,
        modifier = modifier
    ) {
        composable<Login> {
            LoginScreen(
                loginSucesso = {
                    navController.navigate(Futebol) {
                        popUpTo(Login) { inclusive = true }
                    }
                },
                irCadastro = { navController.navigate(Cadastro) },
                authViewModel = viewModel()
            )
        }

        composable<Cadastro> {
            CadastroScreen(
                irLogin = {
                    navController.popBackStack()
                },
                authViewModel = viewModel()
            )
        }

        composable<Futebol> {
            JogosScreen(jogos = jogosDeFutebol(), viewModel = viewModel())
        }

        composable<Basquete> {
            JogosScreen(jogos = jogosDeBasquete(), viewModel = viewModel())
        }

        composable<Bilhetes> {
            BilhetesScreen(viewModel = viewModel())
        }

        composable<Usuarios> { entrada ->
            val usuarioViewModel: UsuarioViewModel = viewModel()
            DisposableEffect(entrada) {
                val observer = LifecycleEventObserver { _, evento ->
                    if (evento == Lifecycle.Event.ON_RESUME) usuarioViewModel.listar()
                }
                entrada.lifecycle.addObserver(observer)
                onDispose { entrada.lifecycle.removeObserver(observer) }
            }
            UsuariosScreen(
                viewModel = usuarioViewModel,
                irParaCadastro = { navController.navigate(CadastrarUsuario) },
                irParaEdicao = { navController.navigate(UsuarioEditar(it)) },
                voltar = { navController.popBackStack() }
            )
        }

        composable<CadastrarUsuario> {
            CadastroScreen(
                authViewModel = viewModel(),
                irLogin = {
                    navController.popBackStack()
                }
            )
        }

        composable<Times> {
            RegistrosScreen(tipo = "times", titulo = "Times cadastrados", viewModel = viewModel<RegistroViewModel>())
        }
        composable<Campanhas> {
            RegistrosScreen(tipo = "campanhas", titulo = "Campanhas do Bem", viewModel = viewModel<RegistroViewModel>())
        }
        composable<ConsultarCep> {
            ConsultaCepScreen(viewModel = viewModel<CepViewModel>())
        }

        composable<UsuarioEditar> { entrada ->
            val rota = entrada.toRoute<UsuarioEditar>()
            UsuarioEditarScreen(
                usuarioId = rota.id,
                viewModel = viewModel(),
                voltar = {
                    navController.popBackStack()
                }
            )
        }
    }
}
