package com.example.betdobem.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.betdobem.data.model.Aposta
import com.example.betdobem.ui.theme.CinzaCard
import com.example.betdobem.ui.theme.Laranja
import com.example.betdobem.ui.viewmodel.ApostaViewModel

// Tela de Bilhetes: lista as apostas, altera o valor e remove
@Composable
fun BilhetesScreen(
    viewModel: ApostaViewModel
) {
    // Busca as apostas no banco quando a tela abre
    LaunchedEffect(Unit) { viewModel.listar() }

    var excluirId by rememberSaveable { mutableStateOf<Long?>(null) }

    // Soma o retorno de todas as apostas (laço for)
    var totalRetorno = 0.0
    for (aposta in viewModel.apostas) {
        totalRetorno += aposta.retornoPotencial()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .imePadding()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Meus Bilhetes",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Laranja
            )
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "Seu saldo", fontSize = 11.sp)
                Text(text = "R$ %.2f".format(viewModel.saldo), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        viewModel.mensagem?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = Laranja, fontWeight = FontWeight.Bold)
        }
        if (viewModel.carregando) CircularProgressIndicator()

        Spacer(modifier = Modifier.height(16.dp))

        if (!viewModel.carregando && viewModel.apostas.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                Text(text = "Nenhuma aposta adicionada ainda.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(viewModel.apostas, key = { it.id }) { aposta ->
                    CardAposta(
                        aposta = aposta,
                        habilitado = !viewModel.carregando,
                        onAlterar = { novoValor -> viewModel.alterarValor(aposta, novoValor) },
                        onRemover = { excluirId = aposta.id }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CinzaCard, shape = RoundedCornerShape(12.dp))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Retorno total:", fontWeight = FontWeight.Bold)
                Text(text = "R$ %.2f".format(totalRetorno), color = Laranja, fontWeight = FontWeight.Bold)
            }
        }
    }

    val selecionada = viewModel.apostas.firstOrNull { it.id == excluirId }
    if (selecionada != null) {
        AlertDialog(
            onDismissRequest = { excluirId = null },
            title = { Text("Remover aposta?") },
            text = { Text("Remover a aposta em ${selecionada.timeCasa} x ${selecionada.timeFora}? R$ %.2f volta para o saldo.".format(selecionada.valor)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        excluirId = null
                        viewModel.excluir(selecionada)
                    },
                    enabled = !viewModel.carregando
                ) { Text("Remover") }
            },
            dismissButton = { TextButton(onClick = { excluirId = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun CardAposta(
    aposta: Aposta,
    habilitado: Boolean,
    onAlterar: (String) -> Unit,
    onRemover: () -> Unit
) {
    // Valor digitado para alterar a aposta
    var novoValor by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CinzaCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "${aposta.timeCasa} x ${aposta.timeFora}",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            LinhaInfo("Palpite", aposta.tipo)
            LinhaInfo("Odd", "%.2f".format(aposta.odd))
            LinhaInfo("Valor apostado", "R$ %.2f".format(aposta.valor))
            LinhaInfo("Retorno possível", "R$ %.2f".format(aposta.retornoPotencial()))

            Spacer(modifier = Modifier.height(4.dp))

            // Alterar o valor: digita o novo valor e confirma
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = novoValor,
                    onValueChange = { if (it.length <= 10) novoValor = it },
                    label = { Text("Novo valor (R$)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        onAlterar(novoValor)
                        novoValor = ""
                    },
                    enabled = habilitado && novoValor.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Laranja)
                ) { Text("Alterar") }
            }

            OutlinedButton(
                onClick = onRemover,
                enabled = habilitado,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Remover aposta", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

// Uma linha "rótulo ............ valor"
@Composable
fun LinhaInfo(rotulo: String, valor: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = rotulo)
        Text(text = valor, fontWeight = FontWeight.Bold)
    }
}
