package com.example.betdobem.data.model

// tipo pode ser: "Casa", "Empate" ou "Fora"
data class Aposta(
    val id: Long,
    val timeCasa: String,
    val timeFora: String,
    val tipo: String,
    val odd: Double,
    val valor: Double
) {
    // Quanto o usuário pode receber se a aposta for vencedora
    fun retornoPotencial(): Double {
        return valor * odd
    }
}
