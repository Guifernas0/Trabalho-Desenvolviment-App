package com.example.betdobem.data.dal

import android.content.ContentValues
import android.content.Context
import com.example.betdobem.data.local.AppDatabase
import com.example.betdobem.data.model.Registro

// Um CRUD por tabela: "times" e "campanhas". Nunca aceitar nomes arbitrários em SQL.
internal class RegistroDao(context: Context, tipo: String) {
    private val appContext = context.applicationContext
    private val tabela = when (tipo) {
        "times" -> "times"
        "campanhas" -> "campanhas"
        else -> throw IllegalArgumentException("Cadastro inválido")
    }

    fun criar(nome: String, descricao: String): Long = AppDatabase(appContext).use { helper ->
        val valores = ContentValues().apply { put("nome", nome); put("descricao", descricao) }
        helper.writableDatabase.insertOrThrow(tabela, null, valores)
    }

    fun listar(): List<Registro> = AppDatabase(appContext).use { helper ->
        helper.readableDatabase.query(tabela, arrayOf("id", "nome", "descricao"), null, null, null, null, "nome ASC")
            .use { cursor ->
                val resultado = mutableListOf<Registro>()
                while (cursor.moveToNext()) resultado.add(Registro(cursor.getLong(0), cursor.getString(1), cursor.getString(2)))
                resultado
            }
    }

    fun alterar(item: Registro): Boolean = AppDatabase(appContext).use { helper ->
        val valores = ContentValues().apply { put("nome", item.nome); put("descricao", item.descricao) }
        helper.writableDatabase.update(tabela, valores, "id = ?", arrayOf(item.id.toString())) == 1
    }

    fun excluir(id: Long): Boolean = AppDatabase(appContext).use { helper ->
        helper.writableDatabase.delete(tabela, "id = ?", arrayOf(id.toString())) == 1
    }
}
