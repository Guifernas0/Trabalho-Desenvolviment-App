package com.example.betdobem.data.model

import androidx.compose.ui.graphics.Color

// Partida mostrada nas telas de Futebol e Basquete (não fica no banco)
class Jogo(
    val timeCasa: String,
    val corCasa: Color,
    val timeFora: String,
    val corFora: Color,
    val aoVivoCasa: Int,
    val aoVivoFora: Int,
    val oddCasa: Double,
    val oddEmpate: Double,
    val oddFora: Double
)
