package com.example.betdobem.data.model

data class Usuario(
    val id: Long,
    val nome: String,
    val email: String,
    val saldo: Double,
    val cpf: String,
    val estado: String,
    val rua: String,
    val bairro: String,
    val cep: String,
    val ddd: String,
    val celular: String
)
