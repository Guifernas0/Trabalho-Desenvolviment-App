package com.example.betdobem.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

// Esquema de cores escuro, já que o app todo usa fundo preto com laranja
private val EsquemaCoresBetDoBem = darkColorScheme(
    primary = Laranja,
    secondary = LaranjaEscuro,
    background = PretoFundo,
    surface = CinzaCard,
    onPrimary = Branco,
    onBackground = Branco,
    onSurface = Branco
)

@Composable
fun BetDoBemTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = EsquemaCoresBetDoBem,
        typography = Typography,
        content = content
    )
}
