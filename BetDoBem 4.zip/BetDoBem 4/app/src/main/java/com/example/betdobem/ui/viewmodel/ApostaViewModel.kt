package com.example.betdobem.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.betdobem.auth.SessaoUsuario
import com.example.betdobem.data.dal.ApostaDao
import com.example.betdobem.data.dal.UsuarioDao
import com.example.betdobem.data.model.Aposta
import com.example.betdobem.data.model.Jogo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ApostaViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = ApostaDao(application)
    private val usuarioDao = UsuarioDao(application)
    private val valorMinimo = 1.0

    var apostas by mutableStateOf<List<Aposta>>(emptyList())
        private set
    var saldo by mutableStateOf(0.0)
        private set
    var carregando by mutableStateOf(false)
        private set
    var mensagem by mutableStateOf<String?>(null)
        private set

    private fun executar(op: suspend (Long) -> Unit) {
        if (carregando) return
        carregando = true
        mensagem = null
        viewModelScope.launch {
            try {
                val usuarioId = SessaoUsuario.exigirUsuario()
                op(usuarioId)
                // Depois de qualquer operação, recarrega a lista e o saldo do banco
                val lista = withContext(Dispatchers.IO) { dao.listar(usuarioId) }
                val usuario = withContext(Dispatchers.IO) { usuarioDao.buscarPorId(usuarioId) }
                apostas = lista
                saldo = usuario?.saldo ?: 0.0
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                mensagem = e.message
            } catch (e: Exception) {
                mensagem = "Um erro inesperado aconteceu."
            } finally {
                carregando = false
            }
        }
    }

    // Converte o texto digitado ("25" ou "25,50") em número e confere o mínimo
    private fun lerValor(texto: String): Double {
        val valor = texto.trim().replace(",", ".").toDoubleOrNull()
        requireNotNull(valor) { "Digite um valor válido. Ex.: 25 ou 25,50" }
        require(valor >= valorMinimo) { "O valor mínimo da aposta é R$ 1,00." }
        return valor
    }

    fun listar() = executar { }

    fun apostar(jogo: Jogo, tipo: String, odd: Double, valorTexto: String) = executar { usuarioId ->
        val valor = lerValor(valorTexto)
        withContext(Dispatchers.IO) {
            val usuario = requireNotNull(usuarioDao.buscarPorId(usuarioId)) { "Usuário não encontrado" }
            require(usuario.saldo >= valor) { "Saldo insuficiente. Você tem R$ %.2f.".format(usuario.saldo) }
            dao.cadastrar(usuarioId, jogo.timeCasa, jogo.timeFora, tipo, odd, valor)
            usuarioDao.alterarSaldo(usuarioId, usuario.saldo - valor)
        }
        mensagem = "Aposta de R$ %.2f em %s adicionada aos bilhetes.".format(valor, tipo)
    }

    // Troca o valor da aposta: a diferença sai do saldo (ou volta, se diminuir)
    fun alterarValor(aposta: Aposta, valorTexto: String) = executar { usuarioId ->
        val novoValor = lerValor(valorTexto)
        val diferenca = novoValor - aposta.valor
        withContext(Dispatchers.IO) {
            val usuario = requireNotNull(usuarioDao.buscarPorId(usuarioId)) { "Usuário não encontrado" }
            require(usuario.saldo >= diferenca) { "Saldo insuficiente. Você tem R$ %.2f.".format(usuario.saldo) }
            dao.alterar(aposta.id, novoValor, usuarioId)
            usuarioDao.alterarSaldo(usuarioId, usuario.saldo - diferenca)
        }
        mensagem = "Valor alterado para R$ %.2f.".format(novoValor)
    }

    fun excluir(aposta: Aposta) = executar { usuarioId ->
        withContext(Dispatchers.IO) {
            val usuario = requireNotNull(usuarioDao.buscarPorId(usuarioId)) { "Usuário não encontrado" }
            dao.excluir(aposta.id, usuarioId)
            usuarioDao.alterarSaldo(usuarioId, usuario.saldo + aposta.valor)
        }
        mensagem = "Aposta removida."
    }
}
