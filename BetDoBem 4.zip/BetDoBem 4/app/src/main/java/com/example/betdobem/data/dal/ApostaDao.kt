package com.example.betdobem.data.dal

import android.content.ContentValues
import android.content.Context
import com.example.betdobem.data.local.AppDatabase
import com.example.betdobem.data.model.Aposta

internal class ApostaDao(context: Context) {
    private val appContext = context.applicationContext

    fun cadastrar(usuarioId: Long,
                  timeCasa: String,
                  timeFora: String,
                  tipo: String,
                  odd: Double,
                  valor: Double
    ) {
        AppDatabase(appContext).use { db ->
            val dados = ContentValues().apply {
                put("usuario_id", usuarioId)
                put("time_casa", timeCasa)
                put("time_fora", timeFora)
                put("tipo", tipo)
                put("odd", odd)
                put("valor", valor)
            }
            db.writableDatabase
                .insertOrThrow("apostas",
                    null,
                    dados)
        }
    }

    fun listar(usuarioId: Long): List<Aposta> = AppDatabase(appContext).use { db ->
        db.readableDatabase.query(
            "apostas",
            arrayOf("id", "time_casa", "time_fora", "tipo", "odd", "valor"),
            "usuario_id = ?",
            arrayOf(usuarioId.toString()),
            null, null,
            "id"
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    add(Aposta(cursor.getLong(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getDouble(4),
                        cursor.getDouble(5)))
                }
            }
        }
    }

    fun alterar(id: Long, valor: Double, usuarioId: Long) {
        AppDatabase(appContext).use { db ->
            val dados = ContentValues().apply {
                put("valor", valor)
            }
            val alterados = db.writableDatabase.update(
                "apostas",
                dados,
                "id = ? AND usuario_id = ?",
                arrayOf(id.toString(), usuarioId.toString()))
            require(alterados == 1) { "Erro ao alterar a aposta" }
        }
    }

    fun excluir(id: Long, usuarioId: Long) {
        AppDatabase(appContext).use { db ->
            val excluidos = db.writableDatabase.delete(
                "apostas", "id = ? AND usuario_id = ?",
                arrayOf(id.toString(), usuarioId.toString())
            )
            require(excluidos == 1) { "Aposta não pode ser excluída" }
        }
    }
}
