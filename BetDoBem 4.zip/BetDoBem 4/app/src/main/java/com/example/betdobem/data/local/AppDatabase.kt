package com.example.betdobem.data.local

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

internal class AppDatabase(context: Context) : SQLiteOpenHelper(
    context.applicationContext, File(context.noBackupFilesDir,
        "betdobem.db").absolutePath,
    null, 2
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE usuarios(
            id INTEGER PRIMARY KEY,
            nome TEXT NOT NULL CHECK(length(nome) BETWEEN 3 AND 100),
            email TEXT NOT NULL UNIQUE CHECK(length(email) BETWEEN 3 AND 254),
            senha BLOB NOT NULL,
            salt BLOB NOT NULL,
            saldo REAL NOT NULL DEFAULT 250.0,
            cpf TEXT NOT NULL DEFAULT '',
            estado TEXT NOT NULL DEFAULT 'PR',
            rua TEXT NOT NULL DEFAULT '',
            bairro TEXT NOT NULL DEFAULT '',
            cep TEXT NOT NULL DEFAULT '',
            ddd TEXT NOT NULL DEFAULT '',
            celular TEXT NOT NULL DEFAULT ''
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE apostas(
            id INTEGER PRIMARY KEY,
            usuario_id INTEGER NOT NULL,
            time_casa TEXT NOT NULL,
            time_fora TEXT NOT NULL,
            tipo TEXT NOT NULL,
            odd REAL NOT NULL,
            valor REAL NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE TABLE times (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, descricao TEXT NOT NULL)")
        db.execSQL("CREATE TABLE campanhas (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, descricao TEXT NOT NULL)")

    }

        
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS times (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, descricao TEXT NOT NULL)")
            db.execSQL("CREATE TABLE IF NOT EXISTS campanhas (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, descricao TEXT NOT NULL)")
        }
    }
}
