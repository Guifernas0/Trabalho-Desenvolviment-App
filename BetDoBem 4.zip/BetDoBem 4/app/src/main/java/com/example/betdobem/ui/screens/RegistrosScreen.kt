package com.example.betdobem.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.betdobem.data.model.Registro
import com.example.betdobem.ui.viewmodel.RegistroViewModel

// Reutiliza somente a interface; cada rota usa sua própria tabela e CRUD completo.
@Composable
fun RegistrosScreen(tipo: String, titulo: String, viewModel: RegistroViewModel) {
    var editando by remember(tipo) { mutableStateOf<Long?>(null) }
    var nome by remember(tipo) { mutableStateOf("") }
    var descricao by remember(tipo) { mutableStateOf("") }
    var paraExcluir by remember { mutableStateOf<Registro?>(null) }
    LaunchedEffect(tipo) { viewModel.listar(tipo) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(titulo, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(if (editando == null) "Novo cadastro" else "Alterando cadastro #$editando")
        OutlinedTextField(nome, { nome = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Nome") })
        OutlinedTextField(descricao, { descricao = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Descrição") }, minLines = 2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                viewModel.salvar(tipo, editando, nome, descricao)
                if (nome.trim().length >= 2 && descricao.isNotBlank()) {
                    editando = null; nome = ""; descricao = ""
                }
            }, enabled = !viewModel.carregando) { Text(if (editando == null) "Cadastrar" else "Salvar alteração") }
            if (editando != null) OutlinedButton(onClick = { editando = null; nome = ""; descricao = "" }) { Text("Cancelar") }
        }
        viewModel.mensagem?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (viewModel.carregando) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text("Cadastros (${viewModel.registros.size})", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(viewModel.registros, key = { it.id }) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(item.nome, style = MaterialTheme.typography.titleMedium)
                        Text(item.descricao)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { editando = item.id; nome = item.nome; descricao = item.descricao }) { Text("Editar") }
                            TextButton(onClick = { paraExcluir = item }) { Text("Excluir") }
                        }
                    }
                }
            }
        }
    }
    paraExcluir?.let { item ->
        AlertDialog(onDismissRequest = { paraExcluir = null }, title = { Text("Excluir ${item.nome}?") },
            text = { Text("Esta ação não pode ser desfeita.") },
            confirmButton = { TextButton(onClick = { viewModel.excluir(tipo, item.id); paraExcluir = null }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { paraExcluir = null }) { Text("Cancelar") } })
    }
}
