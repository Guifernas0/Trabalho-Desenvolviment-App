package com.example.betdobem

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavDestination.Companion.hasRoute
import com.example.betdobem.navigation.Login
import com.example.betdobem.navigation.Cadastro
import com.example.betdobem.navigation.CadastrarUsuario
import com.example.betdobem.auth.SessaoUsuario
import com.example.betdobem.navigation.AppNavigation
import com.example.betdobem.navigation.Menu
import com.example.betdobem.ui.theme.BetDoBemTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BetDoBemTheme {
                val navController = rememberNavController()

                val pilhaRotas by navController.currentBackStackEntryAsState()
                val destino = pilhaRotas?.destination
                val mostrarMenu = SessaoUsuario.usuarioId != null && destino != null &&
                        !destino.hasRoute<Login>() &&
                        !destino.hasRoute<Cadastro>() &&
                        !destino.hasRoute<CadastrarUsuario>()

                Scaffold(
                    topBar = {
                        if (mostrarMenu) {
                            Menu(navController = navController)
                        }
                    }
                ) { innerPadding ->
                    AppNavigation(
                        navController = navController,
                        modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}
