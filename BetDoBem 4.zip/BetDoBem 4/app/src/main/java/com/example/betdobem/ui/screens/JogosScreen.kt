package com.example.betdobem.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.betdobem.data.model.Jogo
import com.example.betdobem.ui.theme.CinzaCard
import com.example.betdobem.ui.theme.Laranja
import com.example.betdobem.ui.viewmodel.ApostaViewModel

// Lista de jogos de futebol
fun jogosDeFutebol(): List<Jogo> = listOf(
    Jogo("CFC", Color(0xFF1D4ED8), "CAP", Color(0xFFB91C1C), 1, 0, 2.10, 3.20, 3.40),
    Jogo("PAL", Color(0xFF15803D), "FLA", Color(0xFFB91C1C), 0, 0, 2.45, 3.10, 2.80),
    Jogo("GRE", Color(0xFF1E3A8A), "INT", Color(0xFFB91C1C), 2, 2, 2.30, 3.00, 3.10)
)

// Lista de jogos de basquete
fun jogosDeBasquete(): List<Jogo> = listOf(
    Jogo("LAL", Color(0xFF5B21B6), "GSW", Color(0xFF1D4ED8), 88, 92, 1.90, 15.00, 1.95),
    Jogo("BOS", Color(0xFF15803D), "MIA", Color(0xFFB91C1C), 101, 95, 1.55, 15.00, 2.50),
    Jogo("CHI", Color(0xFFB91C1C), "NYK", Color(0xFF1D4ED8), 45, 50, 2.20, 15.00, 1.70)
)

// Tela de jogos, usada para Futebol e Basquete (só muda a lista de jogos)
@Composable
fun JogosScreen(
    jogos: List<Jogo>,
    viewModel: ApostaViewModel
) {
    // Busca o saldo no banco quando a tela abre
    LaunchedEffect(Unit) { viewModel.listar() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .imePadding()
    ) {
        CabecalhoComSaldo(saldo = viewModel.saldo)

        viewModel.mensagem?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = Laranja, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(jogos) { jogo ->
                CardJogo(
                    jogo = jogo,
                    habilitado = !viewModel.carregando,
                    onApostar = { tipo, odd, valor -> viewModel.apostar(jogo, tipo, odd, valor) }
                )
            }
        }
    }
}

@Composable
fun CabecalhoComSaldo(saldo: Double) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = "BDB", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Laranja)
            Text(text = "BET DO BEM", fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(text = "Seu saldo", fontSize = 11.sp)
            Text(text = "R$ %.2f".format(saldo), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CardJogo(
    jogo: Jogo,
    habilitado: Boolean,
    onApostar: (String, Double, String) -> Unit
) {
    // Palpite escolhido neste jogo ("Casa", "Empate" ou "Fora") e o valor digitado
    var tipoEscolhido by remember { mutableStateOf<String?>(null) }
    var valor by remember { mutableStateOf("") }

    val oddEscolhida = when (tipoEscolhido) {
        "Casa" -> jogo.oddCasa
        "Empate" -> jogo.oddEmpate
        "Fora" -> jogo.oddFora
        else -> 0.0
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CinzaCard)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Times e placar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                EscudoTime(nome = jogo.timeCasa, cor = jogo.corCasa)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "AO VIVO", fontSize = 10.sp, color = Laranja, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${jogo.aoVivoCasa}  x  ${jogo.aoVivoFora}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                EscudoTime(nome = jogo.timeFora, cor = jogo.corFora)
            }

            Text(text = "Escolha seu palpite:", fontSize = 13.sp)

            // Três botões do mesmo tamanho
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BotaoPalpite(
                    rotulo = "Casa",
                    odd = jogo.oddCasa,
                    selecionado = tipoEscolhido == "Casa",
                    modifier = Modifier.weight(1f)
                ) { tipoEscolhido = "Casa" }
                BotaoPalpite(
                    rotulo = "Empate",
                    odd = jogo.oddEmpate,
                    selecionado = tipoEscolhido == "Empate",
                    modifier = Modifier.weight(1f)
                ) { tipoEscolhido = "Empate" }
                BotaoPalpite(
                    rotulo = "Fora",
                    odd = jogo.oddFora,
                    selecionado = tipoEscolhido == "Fora",
                    modifier = Modifier.weight(1f)
                ) { tipoEscolhido = "Fora" }
            }

            // Depois de escolher o palpite, aparece o campo de valor
            val tipo = tipoEscolhido
            if (tipo != null) {
                OutlinedTextField(
                    value = valor,
                    onValueChange = { if (it.length <= 10) valor = it },
                    label = { Text("Valor da aposta (R$)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                val valorNumero = valor.replace(",", ".").toDoubleOrNull() ?: 0.0
                Text(
                    text = "Retorno possível: R$ %.2f".format(valorNumero * oddEscolhida),
                    color = Laranja,
                    fontWeight = FontWeight.Bold
                )

                Button(
                    onClick = {
                        onApostar(tipo, oddEscolhida, valor)
                        valor = ""
                        tipoEscolhido = null
                    },
                    enabled = habilitado && valor.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Laranja),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Apostar em $tipo", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EscudoTime(nome: String, cor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(cor, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(text = nome.take(3), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// Botão de palpite: laranja quando escolhido, contornado quando não
@Composable
fun BotaoPalpite(
    rotulo: String,
    odd: Double,
    selecionado: Boolean,
    modifier: Modifier,
    aoClicar: () -> Unit
) {
    if (selecionado) {
        Button(
            onClick = aoClicar,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Laranja),
            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp),
            modifier = modifier
        ) { TextoPalpite(rotulo, odd) }
    } else {
        OutlinedButton(
            onClick = aoClicar,
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(vertical = 8.dp, horizontal = 4.dp),
            modifier = modifier
        ) { TextoPalpite(rotulo, odd) }
    }
}

@Composable
fun TextoPalpite(rotulo: String, odd: Double) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = rotulo, fontSize = 12.sp, textAlign = TextAlign.Center)
        Text(text = "%.2f".format(odd), fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}
