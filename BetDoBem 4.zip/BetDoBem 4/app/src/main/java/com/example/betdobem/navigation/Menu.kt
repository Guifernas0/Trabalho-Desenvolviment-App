package com.example.betdobem.navigation

import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController
import com.example.betdobem.auth.SessaoUsuario

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Menu(navController: NavHostController) {
    var aberto by remember { mutableStateOf(false) }
    TopAppBar(
        title = { Text("Bet do Bem") },
        actions = {
            TextButton(onClick = { aberto = true }) { Text("Menu") }
            DropdownMenu(expanded = aberto, onDismissRequest = { aberto = false }) {
                val paginas = listOf(
                    "Futebol" to Futebol,
                    "Basquete" to Basquete,
                    "Bilhetes" to Bilhetes,
                    "Usuários" to Usuarios,
                    "Times" to Times,
                    "Campanhas" to Campanhas,
                    "CEP / Mapas" to ConsultarCep
                )
                paginas.forEach { (titulo, rota) ->
                    DropdownMenuItem(text = { Text(titulo) }, onClick = {
                        aberto = false
                        navController.navigate(rota) { launchSingleTop = true }
                    })
                }
                DropdownMenuItem(text = { Text("Sair da conta") }, onClick = {
                    aberto = false
                    SessaoUsuario.encerrar()
                    navController.navigate(Login) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                })
            }
        }
    )
}
