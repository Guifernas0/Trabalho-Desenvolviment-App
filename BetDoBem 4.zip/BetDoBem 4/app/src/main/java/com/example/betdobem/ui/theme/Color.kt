package com.example.betdobem.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta de cores do app "Bet do Bem"
// Baseada no tema escuro com detalhes em laranja, como no layout original.
val PretoFundo = Color(0xFF0D0D0D)
val Laranja = Color(0xFFFF7A00)
val LaranjaEscuro = Color(0xFFE85D00)
val CinzaCard = Color(0xFF2B2B2B)
val CinzaCampo = Color(0xFF1E1E1E)
val Branco = Color(0xFFFFFFFF)
