package com.example.betdobem.data.model

import com.google.gson.annotations.SerializedName

data class EnderecoCep(
    val cep: String? = null,
    val logradouro: String? = null,
    val bairro: String? = null,
    @SerializedName("localidade") val cidade: String? = null,
    val uf: String? = null,
    val erro: Boolean? = null
)
