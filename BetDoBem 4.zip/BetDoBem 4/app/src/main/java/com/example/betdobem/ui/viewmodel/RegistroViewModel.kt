package com.example.betdobem.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.betdobem.data.dal.RegistroDao
import com.example.betdobem.data.model.Registro
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RegistroViewModel(application: Application) : AndroidViewModel(application) {
    var registros by mutableStateOf<List<Registro>>(emptyList())
        private set
    var carregando by mutableStateOf(false)
        private set
    var mensagem by mutableStateOf<String?>(null)
        private set

    private fun executar(tipo: String, tarefa: suspend (RegistroDao) -> Unit) {
        if (carregando) return
        carregando = true
        mensagem = null
        viewModelScope.launch {
            try {
                val dao = RegistroDao(getApplication(), tipo)
                withContext(Dispatchers.IO) { tarefa(dao); registros = dao.listar() }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { mensagem = e.message ?: "Falha ao salvar dados" }
            finally { carregando = false }
        }
    }
    fun listar(tipo: String) = executar(tipo) { }
    fun salvar(tipo: String, id: Long?, nome: String, descricao: String) {
        val n = nome.trim(); val d = descricao.trim()
        if (n.length < 2 || d.isBlank()) { mensagem = "Informe nome (mínimo 2 letras) e descrição."; return }
        executar(tipo) { dao ->
            if (id == null) require(dao.criar(n, d) > 0) { "Falha ao criar" }
            else require(dao.alterar(Registro(id, n, d))) { "Registro não encontrado" }
        }
    }
    fun excluir(tipo: String, id: Long) = executar(tipo) { dao ->
        require(dao.excluir(id)) { "Registro não encontrado" }
    }
}
