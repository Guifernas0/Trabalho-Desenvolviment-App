package com.example.betdobem.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.betdobem.ui.theme.CinzaCampo
import com.example.betdobem.ui.viewmodel.UsuarioViewModel

@Composable
fun UsuarioEditarScreen(usuarioId: Long,
                        viewModel: UsuarioViewModel,
                        voltar: () -> Unit) {

    LaunchedEffect(usuarioId) { viewModel.buscarPorId(usuarioId) }
    LaunchedEffect(viewModel.salvo) {
        if (viewModel.salvo) {
            viewModel.consumirSalvo()
            voltar()
        }
    }

    var novaSenha by remember { mutableStateOf("") }
    if (viewModel.usuarioAtivoId == null) {
        Text("Faça Login para continuar.")
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Alterar usuário", style = MaterialTheme.typography.headlineMedium)
        viewModel.mensagem?.let { Text(it) }
        if (viewModel.carregando) CircularProgressIndicator()
        val usuario = viewModel.usuario
        if (usuario != null) {
            CampoTexto(rotulo = "Nome", valor = usuario.nome) { novoValor ->
                viewModel.mudarDados(usuario.copy(nome = novoValor))
            }
            OutlinedTextField(
                value = usuario.email,
                onValueChange = {},
                readOnly = true,
                label = { Text("E-mail (não pode ser alterado)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Saldo: R$ %.2f".format(usuario.saldo))

            CampoTexto(rotulo = "CPF", valor = usuario.cpf) { novoValor ->
                viewModel.mudarDados(usuario.copy(cpf = novoValor))
            }

            // Row com dois campos lado a lado: estado (sigla) e rua
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CampoTexto(
                    rotulo = "UF",
                    valor = usuario.estado,
                    modifier = Modifier.width(70.dp)
                ) { novoValor ->
                    viewModel.mudarDados(usuario.copy(estado = novoValor))
                }
                CampoTexto(
                    rotulo = "Rua",
                    valor = usuario.rua,
                    modifier = Modifier.weight(1f)
                ) { novoValor ->
                    viewModel.mudarDados(usuario.copy(rua = novoValor))
                }
            }

            // Row com bairro e CEP
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CampoTexto(
                    rotulo = "Bairro",
                    valor = usuario.bairro,
                    modifier = Modifier.weight(1f)
                ) { novoValor ->
                    viewModel.mudarDados(usuario.copy(bairro = novoValor))
                }
                CampoTexto(
                    rotulo = "CEP",
                    valor = usuario.cep,
                    modifier = Modifier.weight(1f)
                ) { novoValor ->
                    viewModel.mudarDados(usuario.copy(cep = novoValor))
                }
            }

            // Row com DDD e celular
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CampoTexto(
                    rotulo = "DDD",
                    valor = usuario.ddd,
                    modifier = Modifier.width(70.dp)
                ) { novoValor ->
                    viewModel.mudarDados(usuario.copy(ddd = novoValor))
                }
                CampoTexto(
                    rotulo = "Celular",
                    valor = usuario.celular,
                    modifier = Modifier.weight(1f)
                ) { novoValor ->
                    viewModel.mudarDados(usuario.copy(celular = novoValor))
                }
            }

            OutlinedTextField(
                value = novaSenha,
                onValueChange = { if (it.length <= 128) novaSenha = it },
                label = { Text("Nova senha") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                enabled = !viewModel.carregando,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Deixe a senha em branco para manter a atual. Para trocar, use de 6 a 128 caracteres.")
            Button(
                onClick = {
                    viewModel.salvar(novaSenha)
                    novaSenha = ""
                },
                enabled = !viewModel.carregando && !viewModel.salvo
            ) { Text("Salvar alterações") }
        } else if (!viewModel.carregando) {
            TextButton(onClick = { viewModel.buscarPorId(usuarioId) }) { Text("Tentar carregar novamente") }
        }
        TextButton(onClick = voltar, enabled = !viewModel.carregando) { Text("Voltar para usuários") }
    }
}

@Composable
fun CampoTexto(
    rotulo: String,
    valor: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = valor,
        onValueChange = onValueChange,
        label = { Text(rotulo) },
        singleLine = true,
        shape = RoundedCornerShape(24.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = CinzaCampo,
            focusedContainerColor = CinzaCampo
        ),
        modifier = modifier
    )
}
