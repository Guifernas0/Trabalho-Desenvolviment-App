package com.example.betdobem.data.model

data class Registro(val id: Long, val nome: String, val descricao: String)
