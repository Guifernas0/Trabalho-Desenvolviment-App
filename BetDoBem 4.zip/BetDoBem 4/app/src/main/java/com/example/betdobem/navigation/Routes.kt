package com.example.betdobem.navigation

import kotlinx.serialization.Serializable

@Serializable
data object Futebol

@Serializable
data object Basquete

@Serializable
data object Bilhetes

@Serializable
data object Login

@Serializable
data object Cadastro

@Serializable
data object CadastrarUsuario

@Serializable
data class UsuarioEditar(val id: Long)

@Serializable
data object Usuarios

@Serializable
data object Times

@Serializable
data object Campanhas

@Serializable
data object ConsultarCep
