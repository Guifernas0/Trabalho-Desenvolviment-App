package com.example.betdobem.data.remote

import com.example.betdobem.data.model.EnderecoCep
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

interface CepApi {
    @GET("ws/{cep}/json/")
    suspend fun consultar(@Path("cep") cep: String): EnderecoCep
}

object CepService {
    val api: CepApi = Retrofit.Builder()
        .baseUrl("https://viacep.com.br/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(CepApi::class.java)
}
