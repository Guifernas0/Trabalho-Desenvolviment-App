package com.example.betdobem.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.betdobem.ui.viewmodel.CepViewModel

@Composable
fun ConsultaCepScreen(viewModel: CepViewModel) {
    val context = LocalContext.current
    var cep by remember { mutableStateOf("") }
    var enderecoMapa by remember { mutableStateOf("Curitiba, Paraná") }
    var erroMapa by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Consulta de CEP e mapas", style = MaterialTheme.typography.headlineSmall)
        Text("API ViaCEP (Retrofit) e recurso nativo de mapas do celular.")
        OutlinedTextField(cep, { cep = it.take(9) }, label = { Text("CEP") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        Button(onClick = { viewModel.consultar(cep) }, enabled = !viewModel.carregando) { Text("Consultar API") }
        if (viewModel.carregando) CircularProgressIndicator()
        viewModel.mensagem?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        viewModel.endereco?.let { e ->
            val texto = listOfNotNull(e.logradouro, e.bairro, e.cidade, e.uf).filter { it.isNotBlank() }.joinToString(", ")
            Text("Resultado: $texto")
            LaunchedEffect(texto) { enderecoMapa = texto }
        }
        OutlinedTextField(enderecoMapa, { enderecoMapa = it }, label = { Text("Local a localizar") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            erroMapa = false
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(enderecoMapa)}"))
            try { context.startActivity(intent) } catch (e: ActivityNotFoundException) { erroMapa = true }
        }) { Text("Abrir no aplicativo de mapas") }
        if (erroMapa) Text("Nenhum aplicativo de mapas instalado neste aparelho.")
    }
}
